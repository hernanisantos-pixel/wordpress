PACOTE WORDPRESS PLAYGROUND / STUDIO

Arquivos:
- blueprint.json
- hernani-nexus-theme.zip
- site-content.wxr.xml

USO NO WORDPRESS STUDIO
1. Descompacte este pacote ZIP.
2. No Studio: Add site > Start from a blueprint > Choose blueprint file.
3. Selecione o arquivo blueprint.json dentro da pasta descompactada.
4. Finalize a criação do site.

USO NO WORDPRESS PLAYGROUND
1. Hospede o arquivo ZIP final em uma URL pública.
2. Abra o Playground com o parâmetro ?blueprint-url=URL_DO_ZIP

Observações:
- O blueprint instala o tema customizado, importa o conteúdo e configura menu, página inicial e página de posts.
- O visual foi preservado o máximo possível dentro de um tema clássico leve, para facilitar manutenção futura.
