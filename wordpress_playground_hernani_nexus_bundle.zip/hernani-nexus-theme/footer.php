</main>
<footer class="site-footer">
  <div class="site-footer-inner">
    <strong>Hernani Pereira dos Santos</strong><br />
    Perfil acadêmico e página institucional do NEXUS.<br />
    <span>Pacote WordPress Playground preparado para importação local e edição futura.</span>
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
