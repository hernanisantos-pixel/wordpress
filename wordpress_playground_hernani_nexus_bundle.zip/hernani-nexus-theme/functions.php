<?php
function hernani_nexus_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script'));
    register_nav_menus(array('primary' => __('Primary Menu', 'hernani-nexus-theme')));
}
add_action('after_setup_theme', 'hernani_nexus_setup');

function hernani_nexus_scripts() {
    wp_enqueue_style('hernani-nexus-style', get_stylesheet_uri(), array(), '1.0.0');
}
add_action('wp_enqueue_scripts', 'hernani_nexus_scripts');

function hernani_nexus_fallback_menu() {
    echo '<ul class="menu">';
    wp_list_pages(array('title_li' => '', 'depth' => 1));
    echo '</ul>';
}
