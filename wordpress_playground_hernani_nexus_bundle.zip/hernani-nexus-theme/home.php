<?php get_header(); ?>
<div class="posts-grid">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
  <article class="post-card" id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
    <div class="entry-meta"><?php echo esc_html(get_the_date()); ?></div>
    <div class="entry-content"><?php the_excerpt(); ?></div>
    <p><a class="read-more" href="<?php the_permalink(); ?>">Ler mais</a></p>
  </article>
<?php endwhile; else : ?>
  <div class="content-card"><p>Nenhum conteúdo encontrado.</p></div>
<?php endif; ?>
</div>
<?php get_footer(); ?>
